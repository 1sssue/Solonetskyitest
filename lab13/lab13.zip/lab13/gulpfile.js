import { task, src, dest, watch, series, parallel } from 'gulp';
import concat from 'gulp-concat';
import cssnano from 'gulp-cssnano';
const sass = require('gulp-sass')(require('sass'));
import imagemin from 'gulp-imagemin';
import uglify from 'gulp-uglify';
import rename from 'gulp-rename';
import del from 'del';

task('styles', function () {
    return src('src/scss/**/*.scss')
        .pipe(sass().on('error', sass.logError))
        .pipe(cssnano())
        .pipe(rename({ suffix: '.min' }))
        .pipe(dest('dist/css'));
});

task('scripts', function () {
    return src('src/js/**/*.js')
        .pipe(concat('main.js'))
        .pipe(uglify())
        .pipe(rename({ suffix: '.min' }))
        .pipe(dest('dist/js'));
});

task('images', function () {
    return src('src/images/*')
        .pipe(imagemin())
        .pipe(dest('dist/images'));
});

task('clean', function () {
    return del(['dist']);
});

task('watch', function () {
    watch('src/scss/**/*.scss', series('styles'));
    watch('src/js/**/*.js', series('scripts'));
    watch('src/images/*', series('images'));
});

task('default', series('clean', parallel('styles', 'scripts', 'images'), 'watch'));
