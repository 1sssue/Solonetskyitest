//Необхідні пакети
import gulp from 'gulp'; // Основний модуль Gulp
import concat from 'gulp-concat'; // Об'єднання (конкатенація) файлів
import cssnano from 'gulp-cssnano'; // Мінімізація CSS файлів
import gulpSass from 'gulp-sass'; // Компіляція SASS/SCSS в CSS
import * as sass from 'sass'; // Використання SASS як компілятора для gulp-sass
import imagemin from 'gulp-imagemin'; // Оптимізація зображень
import uglify from 'gulp-uglify'; // Мінімізація JavaScript файлів
import rename from 'gulp-rename'; // Зміна імен файлів
import { deleteAsync } from 'del'; // Видалення файлів чи папок асинхронно

//Ініціалізація SASS
const sassCompiler = gulpSass(sass); 

//завдання (умова) "styles": компіляція SCSS у CSS, збереж в папці dist/css
gulp.task('styles', function () {
    return gulp.src('src/scss/style.scss') //Місце SCSS файлів
        .pipe(sassCompiler().on('error', sassCompiler.logError)) //Компіляція - обробка помилок
        .pipe(cssnano()) //Мінімізація CSS файлу
        .pipe(rename({ suffix: '.min' })) //+суфікс ".min" до імені файлу
        .pipe(gulp.dest('dist/css')); //Збереження у папці dist/css
});

//Завдання "scripts": об'єднання JavaScript файлів, збереження в dist/js
gulp.task('scripts', function () {
    return gulp.src('src/js/**/*.js') //Спостерігач JavaScript файлів (зміни ни місцях *)
        .pipe(concat('main.js')) //Об'єднання всіх JS файлів в один main.js
        .pipe(uglify()) //Мінімізація JS файлу
        .pipe(rename({ suffix: '.min' })) //Додавання суфіксу ".min"
        .pipe(gulp.dest('dist/js')); //Збереження у папці dist/js
});

// Завдання "images": оптимізація зображень і збереження в папці dist/images
gulp.task('images', function () {
    return gulp.src('src/images/*') //Джерело зображень (* подальші зображення що будуть надходити)
        .pipe(imagemin()) // Оптимізація зображень
        .pipe(gulp.dest('dist/images')); // Збереження у папці dist/images
});

// Завдання "clean": видалення папки dist
gulp.task('clean', function () {
    return deleteAsync(['dist']); // Асинхронне видалення папки dist
});

//Завдання "watch": слідкування за змінами в SCSS, JS та зображеннях
gulp.task('watch', function () {
    gulp.watch('src/scss/**/*.scss', gulp.series('styles')); // Якщо змінились SCSS файли, запускає styles
    gulp.watch('src/js/**/*.js', gulp.series('scripts')); // Якщо змінились JS файли, запускає scripts
    gulp.watch('src/images/*', gulp.series('images')); // Якщо змінились зображення, запускає images
});

// Завдання "default": очищення папки dist, запуск стилів, скриптів, зображень та watch
gulp.task('default', gulp.series('clean', gulp.parallel('styles', 'scripts', 'images'), 'watch'));
